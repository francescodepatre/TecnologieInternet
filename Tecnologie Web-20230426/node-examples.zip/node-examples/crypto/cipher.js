
const crypto = require('crypto');
const secret = 'pprvbraumutjsrssaizxyvvlgllojzlw' //32
const iv = Buffer.from(crypto.randomBytes(16)); // a Buffer with 16 random bytes
const ivHex = iv.toString("hex");

const cipher = crypto.createCipheriv('aes-256-ctr', Buffer.from(secret), iv);

const encryptedPassword = Buffer.concat([
        cipher.update('mypassword'),
        cipher.final(),
    ]); // encrypted password (still Buffered, though)

const encryptedPasswordHex = encryptedPassword.toString("hex");

console.log(encryptedPasswordHex);


const decipher = crypto.createDecipheriv('aes-256-ctr', Buffer.from(secret), Buffer.from(ivHex, "hex"));
const decryptedPassword = Buffer.concat([decipher.update(Buffer.from(encryptedPasswordHex, "hex")),decipher.final()]);

console.log(decryptedPassword.toString());
