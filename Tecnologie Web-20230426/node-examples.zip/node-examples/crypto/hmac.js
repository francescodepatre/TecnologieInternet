
const crypto = require('crypto');

const hmacHex = crypto.createHmac('sha256','password').update("If you love node so much why don't you marry it?").digest('hex');

console.log(hmacHex);
