
const crypto = require('crypto');

const hashHex = crypto.createHash('sha256').update('Man oh man do I love node!').digest('hex');

console.log(hashHex);
