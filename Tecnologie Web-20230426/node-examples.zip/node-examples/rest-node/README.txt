
Node.js and RESTful services
----------------------------
https://expressjs.com/
https://scotch.io/tutorials/use-expressjs-to-get-url-and-post-parametersUsare la shell di sistema:

1) cd rest-node
2) npm install express
3) nam install body-parser
3) npm install request
4) node server-express.js  
5) node request.js 


Consuming a RESTful service from a JS page using jQuery:https://spring.io/guides/gs/consuming-rest-jquery/
Consuming a RESTful service from a Java client:
- using Java API: http://www.mkyong.com/webservices/jax-rs/restfull-java-client-with-java-net-url/
- using JAX-RS: https://vaadin.com/blog/-/blogs/consuming-rest-services-from-java-applications