let request = require('request');
let fs = require('fs');


request({
    url: "http://localhost:5678/api",
    method: "GET"
}, function (error, response, body){
    console.log(body);
});


request({
    url: "http://localhost:5678/users",
    method: "GET"
}, function (error, response, body){
    console.log(body);
});


request({
    url: "http://localhost:5678/users/2",
    method: "GET"
}, function (error, response, body){
    console.log(body);
});


request({
    url: "http://localhost:5678/echo/pippo",
    method: "GET"
}, function (error, response, body){
    console.log(body);
});


request({
    url: "http://localhost:5678/files/mickeypiano",
    encoding: 'binary',
    method: "GET"
}, function (error, response, body){
	fs.writeFile('mickeypiano.gif', body, 'binary', function (err) {
  		if (err) return console.log(err);
	});
});


var myJSONObject = {"first_name":"Joe"};
request({
    url: "http://localhost:5678/mypost",
    method: "POST",
    json: true,   // <--Very important!!!
    body: myJSONObject
}, function (error, response, body){
    console.log(body);
});
