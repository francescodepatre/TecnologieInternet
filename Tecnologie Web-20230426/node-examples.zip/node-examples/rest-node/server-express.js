let http = require('http');
let fs = require('fs');
let myurl = require('url');
let express = require('express');
let bodyParser = require('body-parser');

let server = express();
server.use(bodyParser.json()); // support json encoded bodies
server.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

server.listen(5678, function () {
	console.log('========= SERVER INFO =========');
	console.log('        Server started!!       ');
	console.log('===============================');
	console.log('\n\n');
});

/***** RESTful API *****/

/*****     GET     *****/
server.get('/api',	 getApiInfo);
server.get('/echo/:name', getEcho);
server.get('/files/:name',	 getFile);
server.get('/users', listUsers);
server.get('/users/:id', getUserById);

/*****     POST     *****/
server.post('/mypost', myPostHandler);


/***** Endpoints *****/

function getEcho(req, res) {
  console.log('API - GET: /echo/:name ==> getEcho(..)');
  res.send(req.params);
}


function getFile(request, response) {
	console.log('API - GET: /file/:name ==> getFile(..)');

  let resource = request.params.name;
  console.log(request.params.name);

  let absPath = './files/'+resource+'.gif';

  fs.exists(absPath, function(exists) {
	if (exists) {
      let img = fs.readFileSync(absPath);
      response.writeHead(200, {'Content-Type': 'image/gif' });
      response.end(img, 'binary');
    } else {
      response.writeHead(200, {'Content-Type': 'text/plain' });
      response.end('Requested file does not exist! \n');
    }
  });
}


function listUsers(request, response) {
	console.log('API - GET: /users ==> listUsers(..)');
	fs.readFile( __dirname + "/files/" + "users.json", 'utf8', function (err, data) {
       console.log( data );
       response.end( data );
   });
}


function getUserById(request, response) {
	console.log('API - GET: /users/:id ==> getUserById(..)');
  fs.readFile( __dirname + "/files/" + "users.json", 'utf8', function (err, data) {
       users = JSON.parse( data );
       let user = users["user" + request.params.id]
       console.log(user);
       response.end(JSON.stringify(user));
  });
}


// test with:
// curl -X POST -H "Content-Type: application/json" -d '{"first_name":"Joe"}' http://localhost:5678/mypost

function myPostHandler(request, response) {
	console.log('API - POST: /mypost ==> myPostHandler(..)');
    // Get the first_name value from the POSTed data
    let first_name = request.body.first_name;

    // Send back the value they posted
    response.send("You posted a first name of " + first_name);
}


/***** Supports Functions *****/

function getApiInfo (request, response) {
	console.log('API - GET: /api ==> getApiInfo(..)');

	response.writeHead(200, {'Content-Type': 'text/plain'});
	response.write('----- RESTful Service API Informations -----\n');
	response.write('\nHTTP GET:\n');
	response.write('\t/echo/:name - Return the element (if exists) with specific name (JSON Element).\n');
	response.write('\t/file/:name - Return the file (if exists) with specific name.\n');
	response.write('\t/users - Return a list of users.\n');
	response.write('\t/user/:id - Return a user by id.\n');
	response.write('\nHTTP POST:\n');
	response.write('\t/mypost - Upload data (JSON element).\n');
	response.write('\n----- ----- ----- ----- -----\n');
	response.write('\nJSON element example\n');
	response.write('\t{\n');
	response.write('\t\t"name" : "Joe",\n');
	response.write('\t}\n');
	response.end();
};
