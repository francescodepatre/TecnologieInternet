let net = require('net');

let server = net.createServer(function(socket) {  // server is a net.Server, socket is a net.Socket
  socket.on('data', function(data) {
    socket.write(data);
  });
});

server.listen(8888);
