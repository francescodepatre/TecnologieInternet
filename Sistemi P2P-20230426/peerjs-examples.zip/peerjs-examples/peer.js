
$(document).ready(function(){

  $("#call").hide();

  const video = document.querySelector('video');
  video.width = 300;
  video.height = 200;
  var peer = new Peer(); // create Peer object with predefined ID
  var otherPeer = null;
  var getUserMedia = (function () {
    if (navigator.getUserMedia) {
      return navigator.getUserMedia.bind(navigator)
    }
    if (navigator.webkitGetUserMedia) {
      return navigator.webkitGetUserMedia.bind(navigator)
    }
    if (navigator.mozGetUserMedia) {
      return navigator.mozGetUserMedia.bind(navigator)
    }
  })();

  peer.on('open', function(id) {
    $("#para").text('My peer ID is: ' + id);
  });

  peer.on('error', function (err) {
    console.log(err);
    alert('' + err);
  });

  peer.on('connection', function(conn) {
    conn.on('data', function(data){
      $("#para2").text("Connection from " + conn.peer);
      $("#para3").text('Peer ' + conn.peer + ' said ' + data);
    });
    $("#call").show();
  });

  peer.on('call', function(call) {
    getUserMedia({video: true, audio: true}, function(stream) {
      call.answer(stream); // Answer the call with an A/V stream.
      call.on('stream', function(remoteStream) {
        video.srcObject = remoteStream;
      });
    }, function(err) {
      console.log('Failed to get local stream' ,err);
    });
  });

  $("#connect").on('click', function() {
    if ( $("#otherPeer").val() != null ) {
      $("#remote").hide();
      var conn = peer.connect($("#otherPeer").val());
      conn.on('open', function() {
        otherPeer = conn.peer;
        $("#para2").text('Connected to: ' + otherPeer);
        conn.send('hi!');
        $("#call").show();
      });
    };
  });

  $("#call").on('click', function() {
    getUserMedia({video: true, audio: true}, function(stream) {
      var call = peer.call(otherPeer, stream);
      call.on('stream', function(remoteStream) {
        // Show stream in some video/canvas element.
        video.srcObject = remoteStream;
      });
    }, function(err) {
      console.log('Failed to get local stream' ,err);
    });
  });

});
